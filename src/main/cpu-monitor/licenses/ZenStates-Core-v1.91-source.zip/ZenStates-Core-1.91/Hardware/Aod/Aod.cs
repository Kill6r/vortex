using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Management;
using System.Text;
using ZenStates.Core.Common;
using ZenStates.Core.Dictionaries;
using ZenStates.Core.Drivers;
using ZenStates.Core.Hardware.DRAM;
using static ZenStates.Core.Hardware.ACPI;

namespace ZenStates.Core.Hardware.Aod
{
    public class AOD
    {
        internal readonly IODriver io;
        internal readonly Cpu cpuInstance;
        public readonly ACPI acpi;
        internal readonly Cpu.CodeName codeName;
        internal readonly uint patchLevel;
        internal readonly bool hasRMP;
        public AodTable Table;

        [Serializable]
        public class AodTable
        {
            public readonly uint Signature;
            public ulong OemTableId;
            // public readonly byte[] RegionSignature;
            public uint BaseAddress;
            public int Length;
            public ACPITable? AcpiTable;
            public AodData Data;
            public byte[] RawAodTable;
            public Dictionary<string, string> AcpiNames;

            public AodTable()
            {
                this.Signature = Signature(TableSignature.SSDT);
                this.OemTableId = SignatureUL(TableSignature.AOD_);
                //this.RegionSignature = ByteSignature(TableSignature.AODE);
            }
        }

        public AOD(IODriver io, Cpu cpuInstance)
        {
            this.io = io;
            this.cpuInstance = cpuInstance;
            this.codeName = this.cpuInstance.info.codeName;
            this.acpi = new ACPI(io);
            this.Table = new AodTable();
            this.patchLevel = this.cpuInstance.info.patchLevel;
            this.hasRMP = GetWmiFunctions().ContainsKey("Set RMP Profile");
            this.Init();
        }

        /*private ACPITable? GetAcpiTable()
        {
            // Try to get the table from RSDT first
            ACPITable? acpiTable = GetAcpiTableFromRsdt();
            if (acpiTable == null)
                return AOD.GetAcpiTableFromRegistry();
            return acpiTable;
        }*/

        /*private ACPITable? GetAcpiTableFromRsdt()
        {
            try
            {
                RSDT rsdt = acpi.GetRsdt();

                foreach (uint addr in rsdt.Data)
                {
                    if (addr != 0)
                    {
                        try
                        {
                            SDTHeader hdr = acpi.GetHeader<SDTHeader>(addr);
                            if (
                                hdr.Signature == this.Table.Signature
                                && (hdr.OEMTableID == this.Table.OemTableId ||
                                hdr.OEMTableID == SignatureUL(TableSignature.AAOD) ||
                                hdr.OEMTableID == SignatureUL(TableSignature.LENOVO_AOD))
                            )
                            {
                                return ParseSdtTable(io.ReadMemory(new IntPtr(addr), (int)hdr.Length));
                            }
                        }
                        catch { }
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error getting SSDT ACPI table from RSDT: {ex.Message}");
            }

            return null;
        }*/

        private static ACPITable? GetAcpiTableFromRegistry()
        {
            string acpiRegistryPath = @"HARDWARE\ACPI";

            RegistryKey acpiKey = null;

            try
            {
                acpiKey = Registry.LocalMachine.OpenSubKey(acpiRegistryPath);

                if (acpiKey != null)
                {
                    string[] subkeyNames = acpiKey.GetSubKeyNames();
                    foreach (string subkeyName in subkeyNames)
                    {
                        Debug.WriteLine($"Subkey: {subkeyName}");

                        if (subkeyName.StartsWith("SSD"))
                        {
                            byte[] acpiTableData = GetRawTableFromSubkeys(acpiKey, subkeyName);
                            if (acpiTableData != null)
                            {
                                if (GetAodRegionIndex(acpiTableData) == -1)
                                    continue;

                                return ParseSdtTable(acpiTableData);
                            }
                        }
                    }
                }
                else
                {
                    Debug.WriteLine("ACPI registry key not found.");
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"Error accessing ACPI registry: {ex.Message}");
            }
            finally
            {
                acpiKey?.Close();
            }

            return null;
        }

        private static int GetAodRegionIndex(byte[] rawTable)
        {
            if (rawTable == null)
                return -1;

            int regionIndex = Utils.FindSequence(rawTable, 0, ByteSignature(TableSignature.AODE));
            if (regionIndex == -1)
                regionIndex = Utils.FindSequence(rawTable, 0, ByteSignature(TableSignature.AODT));
            return regionIndex;
        }

        private static byte[] GetRawTableFromSubkeys(RegistryKey parentKey, string subkeyName)
        {
            RegistryKey subkey = null;
            try
            {
                subkey = parentKey.OpenSubKey(subkeyName);
                if (subkey != null)
                {
                    string[] subkeyNames = subkey.GetSubKeyNames();
                    if (subkeyNames.Length == 0)
                    {
                        // Found a key without further subkeys, retrieve the first REG_BINARY value
                        foreach (string valueName in subkey.GetValueNames())
                        {
                            object value = subkey.GetValue(valueName);

                            if (value is byte[] rawTable)
                            {
                                return rawTable;
                            }
                        }

                        Debug.WriteLine($"No REG_BINARY value found in {subkeyName}.");
                    }
                    else
                    {
                        // Continue drilling down if there are more subkeys
                        foreach (string nestedSubkeyName in subkeyNames)
                        {
                            Debug.WriteLine($"Nested Subkey: {nestedSubkeyName}");
                            byte[] rawTable = GetRawTableFromSubkeys(subkey, nestedSubkeyName);
                            if (rawTable != null)
                            {
                                return rawTable;
                            }
                        }
                    }
                }
            }
            finally
            {
                subkey?.Close();
            }

            return null;
        }

        private void Init()
        {
            //Table.AcpiTable = GetAcpiTable();
            Table.AcpiTable = GetAcpiTableFromRegistry();

            if (Table.AcpiTable != null && Table?.AcpiTable.Value.Data != null)
            {
                byte[] acpiData = Table.AcpiTable.Value.Data;
                int regionIndex = GetAodRegionIndex(acpiData);
                if (regionIndex < 0 || regionIndex > acpiData.Length - 16)
                    return;

                byte[] region = new byte[16];
                Buffer.BlockCopy(acpiData, regionIndex, region, 0, 16);
                // OperationRegion(AODE, SystemMemory, Offset, Length)
                OperationRegion opRegion = Utils.ByteArrayToStructure<OperationRegion>(region);
                if (opRegion.Length == null || opRegion.Length.Length < 2)
                    return;

                this.Table.BaseAddress = opRegion.Offset;
                this.Table.Length = (opRegion.Length[1] << 8) | opRegion.Length[0];
                if (this.Table.BaseAddress == 0 || this.Table.Length <= 0)
                    return;

                this.Table.RawAodTable = this.io.ReadMemory(new IntPtr(this.Table.BaseAddress), this.Table.Length);
#pragma warning disable IL2026
                this.Table.Data = AodData.CreateFromByteArray(this.Table.RawAodTable, GetAodDataDictionary(this.codeName, this.patchLevel));
#pragma warning restore IL2026
            }
        }

        struct BaseDictionary { public Dictionary<string, int> Dict; public int LastOffset; }

        // TODO: Make generic for all CPUs
        private BaseDictionary GetBaseDictionaryByFrequency()
        {
            var memoryConfig = cpuInstance.memoryConfig;
            var timings = memoryConfig?.Timings;
            var mclk = (timings != null && timings.Count > 0 ? timings[0].Value?.Ratio : null) * 100 ?? 0;
            if (mclk > 0 && this.Table.RawAodTable != null)
            {
                if (memoryConfig.Type == MemType.LPDDR5)
                {
                    mclk = mclk * 4;
                }

                var tableIndex = Utils.FindLastSequence(this.Table.RawAodTable, 0, Utils.ToBytes2(mclk));
                if (tableIndex > -1)
                {
                    return new BaseDictionary()
                    {
                        Dict = new Dictionary<string, int>()
                        {
                            { "SMTEn", tableIndex - 4 },
                            { "MemClk", tableIndex },
                            { "Tcl", tableIndex + 4 },
                            { "Trcd", tableIndex + 8 },
                            { "Trp", tableIndex + 12},
                            { "Tras", tableIndex + 16 },
                            { "Trc", tableIndex + 20 },
                            { "Twr", tableIndex + 24 },
                            { "Trfc", tableIndex + 28 },
                            { "Trfc2", tableIndex + 32 },
                            { "Trfcsb", tableIndex + 36 },
                            { "Trtp", tableIndex + 40 },
                            { "TrrdL", tableIndex + 44 },
                            { "TrrdS", tableIndex + 48 },
                            { "Tfaw", tableIndex + 52 },
                            { "TwtrL", tableIndex + 56 },
                            { "TwtrS", tableIndex + 60 },
                            { "TrdrdScL", tableIndex + 64 },
                            { "TrdrdSc", tableIndex + 68 },
                            { "TrdrdSd", tableIndex + 72 },
                            { "TrdrdDd", tableIndex + 76 },
                            { "TwrwrScL", tableIndex + 80 },
                            { "TwrwrSc", tableIndex + 84 },
                            { "TwrwrSd", tableIndex + 88 },
                            { "TwrwrDd", tableIndex + 92 },
                            { "Twrrd", tableIndex + 96},
                            { "Trdwr", tableIndex + 100},
                            { "CadBusDrvStren", tableIndex + 104 },
                        },
                        LastOffset = tableIndex + 104
                    };
                }
            }
            return new BaseDictionary { Dict = null, LastOffset = -1 };
        }

        private Dictionary<string, int> GetAodDataDictionary(Cpu.CodeName codeName, uint patchLevel)
        {
            // Disable this specific Lenovo case as it never worked properly and might hinder newer laptops with proper tables
            //if (Table.AcpiTable.Value.Header.OEMTableID == TableSignature.LENOVO_AOD)
            //    return AodDictionaries.AodDataDictionaryV3;

            var baseDictionary = GetBaseDictionaryByFrequency();
            var lastOffset = baseDictionary.LastOffset;
            //var memModule = cpuInstance.memoryConfig?.Modules[0];
            //var isMDie = memModule?.Rank == DRAM.MemRank.SR && memModule.AddressConfig.NumRow > 16;
            //var isDR = memModule?.Rank == DRAM.MemRank.DR;
            //var capacityGB = memModule?.Capacity.SizeInBytes / Math.Pow(1024, (int)memModule?.Capacity.Unit) ?? 0;

            switch (codeName)
            {
                case Cpu.CodeName.StormPeak:
                case Cpu.CodeName.Genoa:
                case Cpu.CodeName.DragonRange:
                    return AodDictionaries.AodDataDictionaryV2;
                //case Cpu.CodeName.Rembrandt:
                //case Cpu.CodeName.VanGogh:
                //case Cpu.CodeName.Mero:
                //case Cpu.CodeName.Mendocino:
                case Cpu.CodeName.Phoenix:
                case Cpu.CodeName.Phoenix2:
                case Cpu.CodeName.HawkPoint:
                case Cpu.CodeName.KrackanPoint:
                case Cpu.CodeName.KrackanPoint2:
                case Cpu.CodeName.StrixPoint:
                case Cpu.CodeName.StrixHalo:
                    if (baseDictionary.Dict != null)
                    {
                        Dictionary<string, int> dict;
                        dict = new Dictionary<string, int>(baseDictionary.Dict)
                        {
                            { "ProcDataDrvStren", lastOffset + 4},
                            { "ProcDataDrvStrenApu", lastOffset + 4},
                            { "ProcCaOdt", lastOffset + 8 },
                            { "ProcCkOdt", lastOffset + 12 },
                            { "ProcDqOdt", lastOffset + 16 },
                            { "ProcDqsOdt", lastOffset + 20 },
                            { "DramDataDrvStren", lastOffset + 24 },

                            { "RttNomWr", lastOffset + 28 },
                            { "RttNomRd", lastOffset + 32 },
                            { "RttWr", lastOffset + 36 },
                            { "RttPark", lastOffset + 40 },
                            { "RttParkDqs", lastOffset + 44 },
                        };

                        if ((codeName == Cpu.CodeName.Phoenix || codeName == Cpu.CodeName.Phoenix2)
                            && cpuInstance.info.cpuName.ToLowerInvariant().Contains("radeon"))
                        {
                            lastOffset += 4;
                        }

                        // Based on a single KrackanPoint debug log, first voltage sits at base + lastOffset + 84 (8920 is base, 9108 is MemVddio)
                        // lastOffset is base + 104 from the GetBaseDictionaryByFrequency()
                        // 8920 + 104 + 84
                        // Assuming other similar codenames use the same layout, since they share SMU commands and are more common than different
                        if (Array.IndexOf(new[] {
                            Cpu.CodeName.KrackanPoint,
                            Cpu.CodeName.KrackanPoint2,
                            Cpu.CodeName.StrixPoint,
                            Cpu.CodeName.StrixHalo }, codeName) >= 0)
                        {
                            lastOffset -= 4;
                        }

                        dict["MemVddio"] = lastOffset + 88;
                        dict["MemVddq"] = lastOffset + 92;
                        dict["MemVpp"] = lastOffset + 96;
                        dict["ApuVddio"] = lastOffset + 100;

                        return dict;
                    }
                    return AodDictionaries.AodDataDictionaryV4;
                case Cpu.CodeName.GraniteRidge:
                case Cpu.CodeName.Turin:
                case Cpu.CodeName.TurinD:
                case Cpu.CodeName.ShimadaPeak:
                    if (baseDictionary.Dict != null)
                    {
                        Dictionary<string, int> dict;

                        if (patchLevel > 0xB404022)
                        {
                            dict = new Dictionary<string, int>(baseDictionary.Dict)
                            {
                                { "RttNomWr", lastOffset + 4 },
                                { "RttNomRd", lastOffset + 8 },
                                { "RttWr", lastOffset + 12 },
                                { "RttPark", lastOffset + 16 },
                                { "RttParkDqs", lastOffset + 20 },

                                { "MemVddio", lastOffset + 56 },
                                { "MemVddq", lastOffset + 60 },
                                { "MemVpp", lastOffset + 64 },
                                { "ApuVddio", lastOffset + 68 },

                                { "ProcOdt", lastOffset + 144 },
                                { "ProcOdtPullUp", lastOffset + 144 },
                                { "ProcOdtPullDown", lastOffset + 148 },
                                { "DramDataDrvStren", lastOffset + 152 },
                                { "DramDqDsPullUp", lastOffset + 152 },
                                { "DramDqDsPullDown", lastOffset + 156 },
                                { "ProcCsDs", lastOffset + 160 },
                                { "ProcCkDs", lastOffset + 164 },
                                { "ProcDataDrvStren", lastOffset + 168 },
                                { "ProcDqDsPullUp", lastOffset + 168 },
                                { "ProcDqDsPullDown", lastOffset +  172 },
                            };

                            // Why?
                            //if ((isMDie && !hasRMP) || (isDR && capacityGB >= 32))
                            if (!hasRMP)
                            {
                                dict["ProcOdt"] = lastOffset + 132;
                                dict["ProcOdtPullUp"] = lastOffset + 132;
                                dict["ProcOdtPullDown"] = lastOffset + 136;
                                dict["DramDataDrvStren"] = lastOffset + 140;
                                dict["DramDqDsPullUp"] = lastOffset + 140;
                                dict["DramDqDsPullDown"] = lastOffset + 140;
                                dict["ProcCsDs"] = lastOffset + 144;
                                dict["ProcCkDs"] = lastOffset + 148;
                                dict["ProcDataDrvStren"] = lastOffset + 152;
                                dict["ProcDqDsPullUp"] = lastOffset + 152;
                                dict["ProcDqDsPullDown"] = lastOffset + 156;
                            }

                            return dict;
                        }
                        else
                        {
                            dict = new Dictionary<string, int>(baseDictionary.Dict)
                            {
                                { "ProcDataDrvStren", lastOffset + 4 },

                                { "RttNomWr", lastOffset + 8 },
                                { "RttNomRd", lastOffset + 12 },
                                { "RttWr", lastOffset + 16 },
                                { "RttPark", lastOffset + 20 },
                                { "RttParkDqs", lastOffset + 24 },

                                { "MemVddio", lastOffset + 60 },
                                { "MemVddq", lastOffset + 64 },
                                { "MemVpp", lastOffset + 68 },
                                { "ApuVddio", lastOffset + 72 },

                                { "ProcOdt", lastOffset + 136 },
                                { "ProcOdtPullUp", lastOffset + 136 },
                                { "ProcOdtPullDown", lastOffset + 140 },
                                { "DramDataDrvStren", lastOffset + 144 }
                            };


                            //if (isMDie && hasRMP)
                            if (!hasRMP)
                            {
                                dict["ProcOdt"] = lastOffset + 148;
                                dict["ProcOdtPullUp"] = lastOffset + 148;
                                dict["ProcOdtPullDown"] = lastOffset + 152;
                                dict["DramDataDrvStren"] = lastOffset + 156;
                            }

                            return dict;
                        }
                    }

                    return AodDictionaries.AodDataDictionary_1Ah_B404023;
                default:
                    return AodDictionaries.AodDataDictionaryV1;
            }
        }

        public string GetReport()
        {
            ReportBuilder report = new ReportBuilder();

            report.AppendHeading("ACPI: AOD Table");

            try
            {
                if (Table == null || Table.AcpiTable == null)
                {
                    report.AppendLine("<AOD table not available>");
                    report.AppendLine();
                    return report.ToString();
                }

                byte[] rawAodTable = Table.RawAodTable;

                report.AppendSection("Metadata");
                report.AppendHexValue("Signature", Table.Signature, 8, 24);
                report.AppendHexValue("OEM Table ID (raw)", Table.OemTableId, 16, 24);
                report.AppendHexValue("Base Address", Table.BaseAddress, 8, 24);
                report.AppendValue("Length", Table.Length, 24);
                report.AppendValue("Has Parsed Data", Table.Data != null, 24);
                report.AppendValue("Raw Table Bytes", rawAodTable != null ? rawAodTable.Length : 0, 24);
                report.AppendLine();

                report.AppendSection("Header");
                var aodAcpiTableHeader = Table.AcpiTable.GetValueOrDefault().Header;
                report.AppendValue("Signature", aodAcpiTableHeader.Signature, 19);
                report.AppendValue("Length", aodAcpiTableHeader.Length, 19);
                report.AppendValue("Revision", aodAcpiTableHeader.Revision, 19);
                report.AppendValue("Checksum", aodAcpiTableHeader.Checksum, 19);
                report.AppendValue("OEMID", aodAcpiTableHeader.OEMID, 19);
                report.AppendValue("OEMTableID", aodAcpiTableHeader.OEMTableID, 19);
                report.AppendValue("OEMRevision", aodAcpiTableHeader.OEMRevision, 19);
                report.AppendValue("CreatorID", aodAcpiTableHeader.CreatorID, 19);
                report.AppendValue("CreatorRevision", aodAcpiTableHeader.CreatorRevision, 19);

                report.AppendLine();
                report.AppendSection("Data");
                report.Append(Table.Data != null ? Table.Data.GetReport() : "<AOD table data not available>" + Environment.NewLine);

                report.AppendLine();
                report.AppendSection("Raw AOD Table");
                if (!report.AppendIndexedBytes(rawAodTable))
                    report.AppendLine("<AOD raw table not available>");

                report.AppendLine();
            }
            catch (Exception ex)
            {
                report.AppendFailure(ex);
                report.AppendLine();
            }

            return report.ToString();
        }

        public static Dictionary<string, uint> GetWmiFunctions()
        {
            Dictionary<string, uint> dict = new Dictionary<string, uint>();

#if NET8_0_OR_GREATER
            if (!System.Runtime.CompilerServices.RuntimeFeature.IsDynamicCodeCompiled)
            {
                Debug.WriteLine("Native AOT detected. Skipping WMI.");
                return dict;
            }
#endif
            if (IsNativeAotFallback())
            {
                return dict;
            }

            return GetWmiFunctionsImpl(dict);

        }

        private static bool IsNativeAotFallback()
        {
            try
            {
                return string.IsNullOrEmpty(typeof(object).Assembly.Location);
            }
            catch
            {
                return true;
            }
        }

        [System.Runtime.CompilerServices.MethodImpl(System.Runtime.CompilerServices.MethodImplOptions.NoInlining)]
        private static Dictionary<string, uint> GetWmiFunctionsImpl(Dictionary<string, uint> dict)
        {
            try
            {
                string wmiAMDACPI = "AMD_ACPI";
                string wmiScope = "root\\wmi";

                string instanceName = WMI.GetInstanceName(wmiScope, wmiAMDACPI);

                if (String.IsNullOrEmpty(instanceName))
                    return dict;

                using (ManagementObject classInstance = new ManagementObject(wmiScope,
                    $"{wmiAMDACPI}.InstanceName='{instanceName}'",
                    null))
                {
                    // Get function names with their IDs
                    string[] functionObjects = { "GetObjectID", "GetObjectID2" };

                    foreach (var functionObject in functionObjects)
                    {
                        try
                        {
                            using (ManagementBaseObject outParams = WMI.InvokeMethod(classInstance, functionObject, null, 0))
                            using (ManagementBaseObject pack = (ManagementBaseObject)outParams?.Properties["pack"].Value)
                            {
                                if (pack != null)
                                {
                                    var ID = (uint[])pack.GetPropertyValue("ID");
                                    var IDString = (string[])pack.GetPropertyValue("IDString");
                                    var Length = (byte)pack.GetPropertyValue("Length");

                                    if (ID == null || IDString == null)
                                        continue;

                                    for (var i = 0; i < Length && i < ID.Length && i < IDString.Length; ++i)
                                    {
                                        if (string.IsNullOrEmpty(IDString[i]))
                                            break;

                                        dict[IDString[i]] = ID[i];
                                    }
                                }
                            }
                        }
                        catch
                        {
                            // ignored
                        }
                    }
                }
            }
            catch
            {
                // ignored
            }

            return dict;
        }

        private static Dictionary<string, string> GetAcpiNames(byte[] table)
        {
            // ACPI AML Opcode for "Name"
            const byte AML_NAME_OP = 0x08;
            Dictionary<string, string> list = new Dictionary<string, string>();

            if (table == null)
                return list;

            // Name opcode + 4-char NameString + 1 value byte = 6 bytes
            for (int i = 0; i <= table.Length - 6; i++)
            {
                // Check for the Name opcode
                if (table[i] == AML_NAME_OP)
                {
                    // Parse the NameString (4 ASCII characters)
                    string name = Encoding.ASCII.GetString(table, i + 1, 4);
                    byte value = table[i + 5];
                    list[name] = value.ToString();
                }
            }
            return list;
        }
    }
}
