// This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0.
// If a copy of the MPL was not distributed with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
// Copyright (C) LibreHardwareMonitor and Contributors.
// Partial Copyright (C) Michael Möller <mmoeller@openhardwaremonitor.org> and Contributors.
// All Rights Reserved.
// Adаpted from LibreHardwareMonitor (https://github.com/LibreHardwareMonitor/LibreHardwareMonitor)
// Motherboard class is not used in Core, use SystemInfo instead.

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Threading;
using ZenStates.Core.OHWM;

namespace ZenStates.Core.Hardware.Motherboard.Lpc
{
    public class LpcIO
    {
        private readonly StringBuilder _report = new StringBuilder();
        private readonly List<ISuperIO> _superIOs = new List<ISuperIO>();

        public LpcIO(SMBios smbios)
        {
            if (!Mutexes.WaitIsaBus(500))
                return;

            try
            {
                Detect(smbios);
            }
            finally
            {
                Mutexes.ReleaseIsaBus();
            }
        }

        public ISuperIO[] SuperIO
        {
            get { return _superIOs.ToArray(); }
        }

        private void ReportUnknownChip(LpcPort port, string type, int chip)
        {
            _report.Append("Chip ID: Unknown ");
            _report.Append(type);
            _report.Append(" with ID 0x");
            _report.Append(chip.ToString("X", CultureInfo.InvariantCulture));
            _report.Append(" at 0x");
            _report.Append(port.RegisterPort.ToString("X", CultureInfo.InvariantCulture));
            _report.Append("/0x");
            _report.AppendLine(port.ValuePort.ToString("X", CultureInfo.InvariantCulture));
            _report.AppendLine();
        }

        private bool DetectSmsc(LpcPort port)
        {
            port.SmscEnter();

            ushort chipId = port.ReadWord(CHIP_ID_REGISTER);

            if (chipId != 0 && chipId != 0xffff)
            {
                port.FindBars();
                port.SmscExit();
                ReportUnknownChip(port, "SMSC", chipId);
            }

            return false;
        }

        private void Detect(SMBios smbios)
        {
            for (int i = 0; i < REGISTER_PORTS.Length; i++)
            {
                LpcPort port = new LpcPort(REGISTER_PORTS[i], VALUE_PORTS[i]);

                if (DetectWinbondFintek(port, smbios))
                    continue;

                if (DetectIT87(port, smbios))
                    continue;

                if (DetectSmsc(port))
                    continue;

                port.Close();
            }
        }

        public string GetReport()
        {
            if (_report.Length > 0)
            {
                return "LpcIO" + Environment.NewLine + Environment.NewLine + _report;
            }

            return null;
        }

        public void Close()
        {
            foreach (ISuperIO superIO in _superIOs)
                superIO.Close();
        }

        private static string GetBoardProductName(SMBios smbios)
        {
            string name = smbios != null && smbios.Board != null ? smbios.Board.ProductName : null;
            return name ?? string.Empty;
        }

        private static string GetBoardManufacturerName(SMBios smbios)
        {
            string name = smbios != null && smbios.Board != null ? smbios.Board.ManufacturerName : null;
            return name ?? string.Empty;
        }

        private bool DetectWinbondFintek(LpcPort port, SMBios smbios)
        {
            // Resolve the board before entering config mode: nothing that can throw should run
            // while the chip is left in it.
            Model motherboardName = Identification.GetModel(GetBoardProductName(smbios));
            Manufacturer motherboardVendor = Identification.GetManufacturer(GetBoardManufacturerName(smbios));

            port.WinbondNuvotonFintekEnter();

            // The detection paths exit config mode themselves (or leave an absent chip alone);
            // this only guarantees the exit when one of them throws.
            bool completed = false;
            try
            {
                bool detected = DetectWinbondFintekEntered(port, motherboardName, motherboardVendor);
                completed = true;
                return detected;
            }
            finally
            {
                if (!completed)
                    port.WinbondNuvotonFintekExit();
            }
        }

        private bool DetectWinbondFintekEntered(LpcPort port, Model motherboardName, Manufacturer motherboardVendor)
        {
            byte logicalDeviceNumber = 0;
            byte id = port.ReadByte(CHIP_ID_REGISTER);
            byte revision = port.ReadByte(CHIP_REVISION_REGISTER);

            Chip chip = Chip.Unknown;

            switch (id)
            {
                case 0x05:
                    switch (revision)
                    {
                        case 0x07:
                            chip = Chip.F71858;
                            logicalDeviceNumber = F71858_HARDWARE_MONITOR_LDN;
                            break;
                        case 0x41:
                            chip = Chip.F71882;
                            logicalDeviceNumber = FINTEK_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0x06:
                    switch (revision)
                    {
                        case 0x01:
                            chip = Chip.F71862;
                            logicalDeviceNumber = FINTEK_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0x07:
                    switch (revision)
                    {
                        case 0x23:
                            chip = Chip.F71889F;
                            logicalDeviceNumber = FINTEK_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0x08:
                    switch (revision)
                    {
                        case 0x14:
                            chip = Chip.F71869;
                            logicalDeviceNumber = FINTEK_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0x09:
                    switch (revision)
                    {
                        case 0x01:
                            chip = Chip.F71808E;
                            logicalDeviceNumber = FINTEK_HARDWARE_MONITOR_LDN;
                            break;
                        case 0x09:
                            chip = Chip.F71889ED;
                            logicalDeviceNumber = FINTEK_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0x10:
                    switch (revision)
                    {
                        case 0x05:
                            chip = Chip.F71889AD;
                            logicalDeviceNumber = FINTEK_HARDWARE_MONITOR_LDN;
                            break;
                        case 0x07:
                            chip = Chip.F71869A;
                            logicalDeviceNumber = FINTEK_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0x11:
                    switch (revision)
                    {
                        case 0x06:
                            chip = Chip.F71878AD;
                            logicalDeviceNumber = FINTEK_HARDWARE_MONITOR_LDN;
                            break;
                        case 0x18:
                            chip = Chip.F71811;
                            logicalDeviceNumber = FINTEK_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0x52:
                    switch (revision)
                    {
                        case 0x17:
                        case 0x3A:
                        case 0x41:
                            chip = Chip.W83627HF;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0x82:
                    switch (revision & 0xF0)
                    {
                        case 0x80:
                            chip = Chip.W83627THF;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0x85:
                    switch (revision)
                    {
                        case 0x41:
                            chip = Chip.W83687THF;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0x88:
                    switch (revision & 0xF0)
                    {
                        case 0x50:
                        case 0x60:
                            chip = Chip.W83627EHF;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xA0:
                    switch (revision & 0xF0)
                    {
                        case 0x20:
                            chip = Chip.W83627DHG;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xA5:
                    switch (revision & 0xF0)
                    {
                        case 0x10:
                            chip = Chip.W83667HG;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xB0:
                    switch (revision & 0xF0)
                    {
                        case 0x70:
                            chip = Chip.W83627DHGP;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xB3:
                    switch (revision & 0xF0)
                    {
                        case 0x50:
                            chip = Chip.W83667HGB;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xB4:
                    switch (revision & 0xF0)
                    {
                        case 0x70:
                            chip = Chip.NCT6771F;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xC3:
                    switch (revision & 0xF0)
                    {
                        case 0x30:
                            chip = Chip.NCT6776F;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xC4:
                    switch (revision & 0xF0)
                    {
                        case 0x50:
                            chip = Chip.NCT610XD;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xC5:
                    switch (revision & 0xF0)
                    {
                        case 0x60:
                            chip = Chip.NCT6779D;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xC7:
                    switch (revision)
                    {
                        case 0x32:
                            chip = Chip.NCT6683D;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xC8:
                    switch (revision)
                    {
                        case 0x03:
                            chip = Chip.NCT6791D;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xC9:
                    switch (revision)
                    {
                        case 0x11:
                            chip = Chip.NCT6792D;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                        case 0x13:
                            chip = Chip.NCT6792DA;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xD1:
                    switch (revision)
                    {
                        case 0x21:
                            chip = Chip.NCT6793D;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xD3:
                    switch (revision)
                    {
                        case 0x52:
                            chip = Chip.NCT6795D;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xD4:
                    switch (revision)
                    {
                        case 0x23:
                            chip = Chip.NCT6796D;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                        case 0x2A:
                            switch (motherboardName)
                            {
                                case Model.X870E_NOVA_WIFI:
                                    chip = Chip.NCT5585D;
                                    break;
                                default:
                                    chip = Chip.NCT6796DR;
                                    break;
                            }
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                        case 0x51:
                            chip = Chip.NCT6797D;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                        case 0x2B:
                            chip = Chip.NCT6798D;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                        case 0x40:
                        case 0x41:
                            chip = Chip.NCT6686D;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xD5:
                    switch (revision)
                    {
                        case 0x92:
                            // MSI AM5/LGA1851 800 Series Motherboard Compatibility (Nuvoton NCT6687DR)
                            // ZenStates-Core only supports AMD, we can only check for vendor here
                            if (motherboardVendor == Manufacturer.MSI)
                            {
                                chip = Chip.NCT6687DR;
                            }
                            else
                            {
                                chip = Chip.NCT6687D;
                            }

                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
                case 0xD8:
                    switch (revision)
                    {
                        case 0x02:
                            switch (motherboardName)
                            {
                                case Model.X870E_NOVA_WIFI:
                                case Model.B650M_HDV_M_2:
                                    chip = Chip.NCT6796DS;
                                    break;
                                default:
                                    chip = Chip.NCT6799D;
                                    break;
                            }

                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                        case 0x06:
                            chip = Chip.NCT6701D;
                            logicalDeviceNumber = WINBOND_NUVOTON_HARDWARE_MONITOR_LDN;
                            break;
                    }

                    break;
            }

            if (chip == Chip.Unknown)
            {
                if (id != 0 && id != 0xff)
                {
                    port.WinbondNuvotonFintekExit();
                    ReportUnknownChip(port, "Winbond / Nuvoton / Fintek", (id << 8) | revision);
                }
            }
            else
            {
                port.FindBars();
                port.Select(logicalDeviceNumber);

                // Some NCT6701D firmware leaves the hardware-monitor logical device disabled.
                if (chip == Chip.NCT6701D && port.ReadByte(LOGICAL_DEVICE_ACTIVATE_REGISTER) == 0)
                    port.WriteByte(LOGICAL_DEVICE_ACTIVATE_REGISTER, LOGICAL_DEVICE_ACTIVATE_ENABLED);

                ushort address = port.ReadWord(BASE_ADDRESS_REGISTER);
                Thread.Sleep(1);
                ushort verify = port.ReadWord(BASE_ADDRESS_REGISTER);

                // The D8 family can expose the runtime base through the alternate 0x64/0x65 pair.
                if (chip == Chip.NCT6701D && address == verify && IsInvalidRuntimeBase(address))
                {
                    address = port.ReadWord(ALTERNATE_BASE_ADDRESS_REGISTER);
                    Thread.Sleep(1);
                    verify = port.ReadWord(ALTERNATE_BASE_ADDRESS_REGISTER);
                }

                ushort vendorId = port.ReadWord(FINTEK_VENDOR_ID_REGISTER);

                // disable the hardware monitor i/o space lock on NCT679XD chips
                if (address == verify &&
                    (chip == Chip.NCT6791D || chip == Chip.NCT6792D || chip == Chip.NCT6792DA || chip == Chip.NCT6793D || chip == Chip.NCT6795D || chip == Chip.NCT6796D || chip == Chip.NCT6796DR || chip == Chip.NCT6796DS || chip == Chip.NCT6798D || chip == Chip.NCT6797D || chip == Chip.NCT6799D || chip == Chip.NCT6701D))
                {
                    port.NuvotonDisableIOSpaceLock();
                }

                port.WinbondNuvotonFintekExit();

                if (address != verify)
                {
                    _report.Append("Chip ID: 0x");
                    _report.AppendLine(chip.ToString("X"));
                    _report.Append("Chip revision: 0x");
                    _report.AppendLine(revision.ToString("X", CultureInfo.InvariantCulture));
                    _report.AppendLine("Error: Address verification failed");
                    _report.AppendLine();

                    return false;
                }

                // some Fintek chips have address register offset 0x05 added already
                if ((address & 0x07) == 0x05)
                    address &= 0xFFF8;

                if (IsInvalidRuntimeBase(address))
                {
                    _report.Append("Chip ID: 0x");
                    _report.AppendLine(chip.ToString("X"));
                    _report.Append("Chip revision: 0x");
                    _report.AppendLine(revision.ToString("X", CultureInfo.InvariantCulture));
                    _report.Append("Error: Invalid address 0x");
                    _report.AppendLine(address.ToString("X", CultureInfo.InvariantCulture));
                    _report.AppendLine();

                    return false;
                }

                switch (chip)
                {
                    case Chip.W83627DHG:
                    case Chip.W83627DHGP:
                    case Chip.W83627EHF:
                    case Chip.W83627HF:
                    case Chip.W83627THF:
                    case Chip.W83667HG:
                    case Chip.W83667HGB:
                    case Chip.W83687THF:
                        _superIOs.Add(new W836XX(port, chip, revision, address));
                        break;

                    case Chip.NCT610XD:
                    case Chip.NCT6771F:
                    case Chip.NCT6776F:
                    case Chip.NCT6779D:
                    case Chip.NCT6791D:
                    case Chip.NCT6792D:
                    case Chip.NCT6792DA:
                    case Chip.NCT6793D:
                    case Chip.NCT6795D:
                    case Chip.NCT6796D:
                    case Chip.NCT6796DR:
                    case Chip.NCT6796DS:
                    case Chip.NCT6797D:
                    case Chip.NCT6798D:
                    case Chip.NCT6799D:
                    case Chip.NCT6686D:
                    case Chip.NCT6687D:
                    case Chip.NCT6687DR:
                    case Chip.NCT6683D:
                    case Chip.NCT6701D:
                    case Chip.NCT5585D:
                        _superIOs.Add(new Nct677X(port, chip, revision, address));
                        break;

                    case Chip.F71858:
                    case Chip.F71862:
                    case Chip.F71869:
                    case Chip.F71878AD:
                    case Chip.F71869A:
                    case Chip.F71882:
                    case Chip.F71889AD:
                    case Chip.F71889ED:
                    case Chip.F71889F:
                    case Chip.F71808E:
                        if (vendorId != FINTEK_VENDOR_ID)
                        {
                            _report.Append("Chip ID: 0x");
                            _report.AppendLine(chip.ToString("X"));
                            _report.Append("Chip revision: 0x");
                            _report.AppendLine(revision.ToString("X", CultureInfo.InvariantCulture));
                            _report.Append("Error: Invalid vendor ID 0x");
                            _report.AppendLine(vendorId.ToString("X", CultureInfo.InvariantCulture));
                            _report.AppendLine();

                            return false;
                        }

                        _superIOs.Add(new F718XX(port, chip, address));
                        break;
                }

                return true;
            }

            return false;
        }

        private bool DetectIT87(LpcPort port, SMBios smbios)
        {
            // IT87XX can enter only on port 0x2E
            // IT8792 using 0x4E
            if (port.RegisterPort != 0x2E && port.RegisterPort != 0x4E)
                return false;

            // Read the chip ID before entering.
            // If already entered (not 0xFFFF) and the register port is 0x4E, it is most likely bugged and should be left alone.
            // Entering IT8792 in this state will result in IT8792 reporting with chip ID of 0x8883.
            // TryReadWord only reports that the read went through, so 0xFFFF (nothing answering in
            // config mode yet) still needs the enter sequence.
            ushort chipId;
            if (port.RegisterPort != 0x4E || !port.TryReadWord(CHIP_ID_REGISTER, out chipId) || chipId == 0xFFFF)
            {
                port.IT87Enter();
                chipId = port.ReadWord(CHIP_ID_REGISTER);
            }

            Chip chip;
            switch (chipId)
            {
                case 0x8613:
                    chip = Chip.IT8613E;
                    break;
                case 0x8620:
                    chip = Chip.IT8620E;
                    break;
                case 0x8625:
                    chip = Chip.IT8625E;
                    break;
                case 0x8628:
                    chip = Chip.IT8628E;
                    break;
                case 0x8631:
                    chip = Chip.IT8631E;
                    break;
                case 0x8638:
                    chip = Chip.IT8638E;
                    break;
                case 0x8665:
                    chip = Chip.IT8665E;
                    break;
                case 0x8655:
                    chip = Chip.IT8655E;
                    break;
                case 0x8686:
                    chip = Chip.IT8686E;
                    break;
                case 0x8688:
                    chip = Chip.IT8688E;
                    break;
                case 0x8689:
                    chip = Chip.IT8689E;
                    break;
                case 0x8696:
                    chip = Chip.IT8696E;
                    break;
                case 0x8705:
                    chip = Chip.IT8705F;
                    break;
                case 0x8712:
                    chip = Chip.IT8712F;
                    break;
                case 0x8716:
                    chip = Chip.IT8716F;
                    break;
                case 0x8718:
                    chip = Chip.IT8718F;
                    break;
                case 0x8720:
                    chip = Chip.IT8720F;
                    break;
                case 0x8721:
                    chip = Chip.IT8721F;
                    break;
                case 0x8726:
                    chip = Chip.IT8726F;
                    break;
                case 0x8728:
                    chip = Chip.IT8728F;
                    break;
                case 0x8771:
                    chip = Chip.IT8771E;
                    break;
                case 0x8772:
                    chip = Chip.IT8772E;
                    break;
                case 0x8790:
                    chip = Chip.IT8790E;
                    break;
                case 0x8733:
                    chip = Chip.IT8792E;
                    break;
                case 0x8695:
                    chip = Chip.IT87952E;
                    break;
                default:
                    chip = Chip.Unknown;
                    break;
            }

            if (chip == Chip.Unknown)
            {
                if (chipId != 0 && chipId != 0xffff)
                {
                    port.IT87Exit();

                    ReportUnknownChip(port, "ITE", chipId);
                }
            }
            else
            {
                port.FindBars();
                port.Select(IT87_ENVIRONMENT_CONTROLLER_LDN);

                ushort address = port.ReadWord(BASE_ADDRESS_REGISTER);
                Thread.Sleep(1);
                ushort verify = port.ReadWord(BASE_ADDRESS_REGISTER);

                byte version = (byte)(port.ReadByte(IT87_CHIP_VERSION_REGISTER) & 0x0F);

                ushort gpioAddress;
                ushort gpioVerify;

                if (chip == Chip.IT8705F)
                {
                    port.Select(IT8705_GPIO_LDN);
                    gpioAddress = port.ReadWord(BASE_ADDRESS_REGISTER);
                    Thread.Sleep(1);
                    gpioVerify = port.ReadWord(BASE_ADDRESS_REGISTER);
                }
                else
                {
                    port.Select(IT87XX_GPIO_LDN);
                    gpioAddress = port.ReadWord(BASE_ADDRESS_REGISTER + 2);
                    Thread.Sleep(1);
                    gpioVerify = port.ReadWord(BASE_ADDRESS_REGISTER + 2);
                }

                IGigabyteController gigabyteController = FindGigabyteEC(port, chip, smbios);
                port.IT87Exit();

                if (address != verify || address < 0x100 || (address & 0xF007) != 0)
                {
                    _report.Append("Chip ID: 0x");
                    _report.AppendLine(chip.ToString("X"));
                    _report.Append("Error: Invalid address 0x");
                    _report.AppendLine(address.ToString("X", CultureInfo.InvariantCulture));
                    _report.AppendLine();

                    gigabyteController?.Dispose();

                    return false;
                }

                if (gpioAddress != gpioVerify || gpioAddress < 0x100 || (gpioAddress & 0xF007) != 0)
                {
                    _report.Append("Chip ID: 0x");
                    _report.AppendLine(chip.ToString("X"));
                    _report.Append("Error: Invalid GPIO address 0x");
                    _report.AppendLine(gpioAddress.ToString("X", CultureInfo.InvariantCulture));
                    _report.AppendLine();

                    gigabyteController?.Dispose();

                    return false;
                }

                _superIOs.Add(new IT87XX(port, chip, address, gpioAddress, version, gigabyteController));

                return true;
            }

            return false;
        }


        private static IGigabyteController FindGigabyteEC(LpcPort port, Chip chip, SMBios smbios)
        {
            // The controller only affects the 2nd ITE chip if present, and only a few
            // models are known to use this controller.
            // IT8795E likely to need this too, but may use different registers.
            string motherboardVendor = GetBoardManufacturerName(smbios);
            if (motherboardVendor.IndexOf("Gigabyte", StringComparison.OrdinalIgnoreCase) < 0 || port.RegisterPort != 0x4E ||
                (chip != Chip.IT8790E && chip != Chip.IT8792E && chip != Chip.IT87952E))
                return null;

            // ECIO is only available on AMD motherboards with IT8791E/IT8792E/IT8795E.
            // ZenStates-Core only supports AMD motherboards, so we can skip the vendor check here.
            if (chip == Chip.IT8792E)
            {
                //IGigabyteController gigabyteController = FindGigabyteECUsingSmfi(port);
                //if (gigabyteController != null)
                //    return gigabyteController;

                IGigabyteController gigabyteController = EcioPortGigabyteController.TryCreate(port);
                if (gigabyteController != null)
                    return gigabyteController;
            }

            return null;
        }

        private static bool IsInvalidRuntimeBase(ushort address)
        {
            return address < 0x100 || (address & 0xF007) != 0;
        }

        // ReSharper disable InconsistentNaming
        private const byte BASE_ADDRESS_REGISTER = 0x60;
        private const byte ALTERNATE_BASE_ADDRESS_REGISTER = 0x64;
        private const byte CHIP_ID_REGISTER = 0x20;
        private const byte CHIP_REVISION_REGISTER = 0x21;

        private const byte F71858_HARDWARE_MONITOR_LDN = 0x02;
        private const byte FINTEK_HARDWARE_MONITOR_LDN = 0x04;
        private const byte IT87_ENVIRONMENT_CONTROLLER_LDN = 0x04;
        private const byte IT8705_GPIO_LDN = 0x05;
        private const byte IT87XX_GPIO_LDN = 0x07;
        private const byte LOGICAL_DEVICE_ACTIVATE_REGISTER = 0x30;
        private const byte LOGICAL_DEVICE_ACTIVATE_ENABLED = 0x01;

        // Shared Memory/Flash Interface
        private const byte WINBOND_NUVOTON_HARDWARE_MONITOR_LDN = 0x0B;

        private const ushort FINTEK_VENDOR_ID = 0x1934;

        private const byte FINTEK_VENDOR_ID_REGISTER = 0x23;
        private const byte IT87_CHIP_VERSION_REGISTER = 0x22;

        private readonly ushort[] REGISTER_PORTS = { 0x2E, 0x4E };

        private readonly ushort[] VALUE_PORTS = { 0x2F, 0x4F };
        // ReSharper restore InconsistentNaming
    }
}